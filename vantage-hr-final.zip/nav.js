/* nav.js — shared navigation injected into every Vantage HR page
   Usage: <script src="nav.js"></script> anywhere in <body>
   It detects which page it's on and highlights the right link. */

(function(){
  const page = location.pathname.split('/').pop() || 'landing.html';
  const isLanding  = page === 'landing.html' || page === '';
  const isApp      = page === 'index.html'   || page === 'app';
  const isPortal   = page === 'portal.html'  || page === 'portal';

  const NAV_HTML = `
<style>
#vhr-shared-nav{
  position:fixed;top:0;left:0;right:0;z-index:9999;
  background:rgba(10,37,24,0.97);backdrop-filter:blur(12px);
  border-bottom:1px solid rgba(255,255,255,0.07);
  font-family:'Inter',system-ui,sans-serif;
}
#vhr-shared-nav .vn-inner{
  max-width:1160px;margin:0 auto;
  display:flex;align-items:center;gap:0;height:54px;padding:0 20px;
}
#vhr-shared-nav .vn-logo{
  display:flex;align-items:center;gap:9px;text-decoration:none;margin-right:24px;
}
#vhr-shared-nav .vn-mark{
  width:30px;height:30px;border-radius:7px;background:#C9A84C;
  display:flex;align-items:center;justify-content:center;
  font-family:Georgia,serif;font-size:15px;font-weight:700;color:#0A2518;flex-shrink:0;
}
#vhr-shared-nav .vn-name{
  font-size:15px;font-weight:700;color:#fff;letter-spacing:-.3px;
}
#vhr-shared-nav .vn-links{
  display:flex;align-items:center;gap:2px;flex:1;
}
#vhr-shared-nav .vn-link{
  font-size:13px;font-weight:500;color:rgba(255,255,255,0.65);
  text-decoration:none;padding:7px 12px;border-radius:7px;
  transition:background 150ms,color 150ms;white-space:nowrap;
}
#vhr-shared-nav .vn-link:hover{color:#fff;background:rgba(255,255,255,0.07);}
#vhr-shared-nav .vn-link.active{color:#fff;background:rgba(255,255,255,0.1);}
#vhr-shared-nav .vn-spacer{flex:1;}
#vhr-shared-nav .vn-cta{
  font-size:13px;font-weight:700;padding:8px 16px;border-radius:8px;
  background:#C9A84C;color:#0A2518;text-decoration:none;border:none;cursor:pointer;
  transition:background 150ms,transform 150ms;white-space:nowrap;
}
#vhr-shared-nav .vn-cta:hover{background:#E0BA5A;transform:translateY(-1px);}
#vhr-shared-nav .vn-cta.outline{
  background:transparent;color:rgba(255,255,255,0.8);
  border:1px solid rgba(255,255,255,0.25);
}
#vhr-shared-nav .vn-cta.outline:hover{border-color:rgba(255,255,255,0.6);color:#fff;}
#vhr-shared-nav .vn-mob{
  display:none;background:transparent;border:none;cursor:pointer;
  color:rgba(255,255,255,0.8);padding:6px;
}
#vhr-mob-drawer{
  display:none;position:fixed;inset:0;z-index:9998;
  background:rgba(10,37,24,0.98);flex-direction:column;padding:72px 24px 32px;
}
#vhr-mob-drawer.open{display:flex;}
#vhr-mob-drawer a{
  font-size:22px;font-family:Georgia,serif;color:rgba(255,255,255,0.85);
  text-decoration:none;padding:14px 0;border-bottom:1px solid rgba(255,255,255,0.07);
}
#vhr-mob-drawer a.active{color:#C9A84C;}
#vhr-mob-drawer .mob-cta{
  margin-top:auto;padding:16px;background:#C9A84C;color:#0A2518;
  font-size:16px;font-weight:700;border-radius:12px;text-align:center;
  text-decoration:none;border-bottom:none;
}
@media(max-width:680px){
  #vhr-shared-nav .vn-links,
  #vhr-shared-nav .vn-spacer{ display:none; }
  #vhr-shared-nav .vn-mob{ display:block; }
}
/* Push page content below fixed nav */
body{ padding-top:54px; }
/* But not on pages that already have their own topbar */
body.has-topbar{ padding-top:0; }
</style>
<nav id="vhr-shared-nav">
  <div class="vn-inner">
    <a href="landing.html" class="vn-logo">
      <div class="vn-mark">V</div>
      <span class="vn-name">Vantage HR</span>
    </a>
    <div class="vn-links">
      <a href="landing.html" class="vn-link ${isLanding?'active':''}">Home</a>
      <a href="index.html"  class="vn-link ${isApp?'active':''}">HR Admin</a>
      <a href="portal.html" class="vn-link ${isPortal?'active':''}">Employee Portal</a>
    </div>
    <div class="vn-spacer"></div>
    ${isApp    ? '<a href="landing.html" class="vn-cta outline">← Back to home</a>' : ''}
    ${isPortal ? '<a href="index.html"  class="vn-cta outline">HR Admin ↗</a>'      : ''}
    ${isLanding? '<a href="index.html"  class="vn-cta">Open app →</a>'              : ''}
    <button class="vn-mob" id="vhr-mob-open" aria-label="Menu">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
      </svg>
    </button>
  </div>
</nav>
<div id="vhr-mob-drawer">
  <a href="landing.html" class="${isLanding?'active':''}">Home</a>
  <a href="index.html"   class="${isApp?'active':''}">HR Admin</a>
  <a href="portal.html"  class="${isPortal?'active':''}">Employee Portal</a>
  <a href="index.html"   class="mob-cta">Open the HR app →</a>
</div>`;

  // Inject nav
  const wrapper = document.createElement('div');
  wrapper.innerHTML = NAV_HTML;
  document.body.insertBefore(wrapper, document.body.firstChild);

  // Mobile drawer toggle
  document.getElementById('vhr-mob-open').addEventListener('click', ()=>{
    document.getElementById('vhr-mob-drawer').classList.toggle('open');
  });
  document.getElementById('vhr-mob-drawer').addEventListener('click', ev=>{
    if(ev.target === ev.currentTarget)
      ev.currentTarget.classList.remove('open');
  });
})();
